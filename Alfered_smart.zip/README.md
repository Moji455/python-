# qroz_rubika_bot


for setting up write the your auth in the line 1482

and install library from the requierments.txt with:
<html>
<pre lang="py3">
 pip install -r requirments.txt
</pre>
<html>
